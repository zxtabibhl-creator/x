import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class AnimeHomePage extends StatefulWidget {
  const AnimeHomePage({super.key});

  @override
  State<AnimeHomePage> createState() => _AnimeHomePageState();
}

class _AnimeHomePageState extends State<AnimeHomePage> {
  final TextEditingController controller = TextEditingController();
  final ScrollController scroll = ScrollController();
  List<dynamic> results = [];
  List<String> history = [];
  bool loading = false;
  int page = 1;

  @override
  void initState() {
    super.initState();
    loadHistory();
    scroll.addListener(() {
      if (scroll.position.pixels >= scroll.position.maxScrollExtent - 300 && !loading) {
        search(controller.text, more: true);
      }
    });
  }

  Future<void> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    history = prefs.getStringList('history') ?? [];
    setState(() {});
  }

  Future<void> saveHistory(String q) async {
    final prefs = await SharedPreferences.getInstance();
    history.remove(q);
    history.insert(0, q);
    await prefs.setStringList('history', history);
  }

  Future<void> search(String q, {bool more = false}) async {
    if (q.isEmpty) return;
    if (!more) {
      page = 1;
      results.clear();
    } else {
      page++;
    }
    setState(() => loading = true);
    final res = await http.get(Uri.parse('https://api.nekolabs.web.id/discovery/xnxx/search?q=$q&page=$page'));
    final data = jsonDecode(res.body);
    results.addAll(data['result'] ?? []);
    await saveHistory(q);
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('XNXX LITE')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: controller,
              onSubmitted: (v) => search(v),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'search for videos'),
            ),
          ),
          Expanded(
            child: GridView.builder(
              controller: scroll,
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.6),
              itemCount: results.length,
              itemBuilder: (c, i) {
                final item = results[i];
                return GestureDetector(
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AnimePlayerPage(data: item))),
                  child: Card(
                    child: Column(
                      children: [
                        Expanded(child: CachedNetworkImage(imageUrl: item['cover'], fit: BoxFit.cover, width: double.infinity)),
                        Padding(padding: const EdgeInsets.all(8), child: Text(item['title'], maxLines: 2, overflow: TextOverflow.ellipsis)),
                        Text('${item['resolution']} • ${item['duration']}', style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 6)
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          if (loading) const Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator())
        ],
      ),
    );
  }
}

class AnimePlayerPage extends StatefulWidget {
  final Map data;
  const AnimePlayerPage({super.key, required this.data});

  @override
  State<AnimePlayerPage> createState() => _AnimePlayerPageState();
}

class _AnimePlayerPageState extends State<AnimePlayerPage> {
  VideoPlayerController? video;
  ChewieController? chewie;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final res = await http.get(Uri.parse('https://api.nekolabs.web.id/downloader/xnxx?url=${widget.data['url']}'));
    final data = jsonDecode(res.body);
    final hls = data['result']['videos']['high'];
    video = VideoPlayerController.networkUrl(Uri.parse(hls));
    await video!.initialize();
    chewie = ChewieController(
      videoPlayerController: video!,
      autoPlay: true,
      allowPlaybackSpeedChanging: true,
      showControls: true,
      subtitle: Subtitles([]),
    );
    setState(() => loading = false);
  }

  @override
  void dispose() {
    chewie?.dispose();
    video?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.data['title'])),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                AspectRatio(aspectRatio: video!.value.aspectRatio, child: Chewie(controller: chewie!)),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(widget.data['title'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text('Play / Pause tersedia, HLS stream aktif')
                  ]),
                )
              ],
            ),
    );
  }
}