import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'anime.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF0B0614),
      ),
      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    await Future.delayed(const Duration(seconds: 2));
    final prefs = await SharedPreferences.getInstance();
    final allowed = prefs.getBool('age_allowed') ?? false;
    if (!allowed) {
      if (!mounted) return;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (c) => AlertDialog(
          title: const Text('Peringatan Usia'),
          content: const Text('Konten hanya untuk usia 14 tahun ke atas'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('Keluar')),
            ElevatedButton(
              onPressed: () async {
                await prefs.setBool('age_allowed', true);
                if (!mounted) return;
                Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => const AnimeHomePage()));
              },
              child: const Text('Saya 14+'),
            )
          ],
        ),
      );
    } else {
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AnimeHomePage()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('XNXX LITE', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
      ),
    );
  }
}